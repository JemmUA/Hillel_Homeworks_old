create function clients_uuidplus() returns void
    language plpgsql
as
$$
DECLARE
uuid varchar;
pointer CURSOR FOR SELECT * FROM clients;

BEGIN
FOR row IN pointer LOOP
uuid = gen_random_uuid();
INSERT INTO clients_updated(id, uuid, name, email, phone, about)
VALUES (row.id, uuid, row.name, row.email, row.phone, row.about);

END LOOP;
END;

$$;

alter function clients_uuidplus() owner to postgres;

