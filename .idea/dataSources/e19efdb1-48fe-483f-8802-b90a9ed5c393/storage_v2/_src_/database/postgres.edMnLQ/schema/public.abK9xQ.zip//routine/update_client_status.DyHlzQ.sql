create function update_client_status() returns trigger
    language plpgsql
as
$$
DECLARE
	cut_id int;
	cut_stat_id int;
BEGIN
	IF	TG_OP = 'INSERT' THEN
		cut_id = NEW.id;
		cut_stat_id = (SELECT id FROM statuses WHERE alias = 'STANDARD');
		INSERT INTO client_status(client_id, status_id) VALUES (cut_id, cut_stat_id);
		RETURN NEW;
		
-- There is nothing to update in table client_status when table clients is updating, excepting case when ID changes in table clients
-- So UPDATE table client_status is pointless. Just for example.
	ELSIF TG_OP = 'UPDATE' THEN
		cut_id = OLD.id;
		UPDATE client_status SET client_id = cut_id WHERE client_id = OLD.id;
		RETURN OLD;
		
	ELSIF TG_OP = 'DELETE' THEN
		cut_id = OLD.id;
		DELETE FROM client_status WHERE client_id = cut_id;
		RETURN OLD;
	END IF;
END;
$$;

alter function update_client_status() owner to postgres;

